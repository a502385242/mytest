package com.demo.controller;
import java.util.Properties;

import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PropertiesLoaderUtils;

public class SpringConfigUtil {

    private static Properties spring_props = new Properties();
    static {
        try {
            Resource resource = new ClassPathResource("/META-INF/config/app-config.properties");
            spring_props = PropertiesLoaderUtils.loadProperties(resource);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static String getValue(String key) {
        String value = "";
        if (spring_props.containsKey(key)) {
            value = spring_props.getProperty(key, "");
        }
        return value;
    }
}
