package com.demo.controller;

public class insertPictureTest {
    public static void main(String[] args) {
        Picture.insertPicture("src\\main\\resources\\document\\测试Excel.xls","src\\main\\resources\\pictures\\link.jpg",1,1);

    }
}
