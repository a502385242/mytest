package com.demo.controller;

import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.http.HttpRequest;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author Steven
 * @version 1.0
 * @description com.demo.controller
 * @date 2020-4-21
 */
@RestController
@RequestMapping("/testExcel")
public class TestEXcelController {

    //http://localhost:8080/testExcel/uploadExcel
    //读取excel内容
    @PostMapping("/uploadExcel")
    public void uploadExcel(@RequestParam("file")MultipartFile multipartFile) {
        Workbook workbook = null;
        String filename = multipartFile.getOriginalFilename();
        try {
            if (filename.endsWith("xls")){
                workbook = new HSSFWorkbook(multipartFile.getInputStream());
            } else if(filename.endsWith("xlsx")){
                workbook = new XSSFWorkbook(multipartFile.getInputStream());
            }
            Sheet sheet =workbook.getSheetAt(0);
            int physicalNumberOfRows = sheet.getPhysicalNumberOfRows();
            //跳过第一行表头
            for (int i = 1; i < physicalNumberOfRows; i++) {
                //获取第一个单元格
                String cell = CommomUtils.getCellValue(sheet,i,0);
            }
        }catch (Exception e){

            e.printStackTrace();
        }

    }

    //http://localhost:8080/testExcel/uploadExcel
    //读取excel内容
    @PostMapping("/downloadExcel")
    public String downloadExcel(HttpServletRequest request, HttpServletResponse response,String  time) {
        String str = time;
        //创建工作薄
        HSSFWorkbook wb = new HSSFWorkbook();
        //创建工作表
        HSSFSheet sheet = wb.createSheet();
        //创建样式和字体
        HSSFCellStyle curStyle = wb.createCellStyle();
        HSSFFont curFont = wb.createFont();
        //创建行列
        HSSFRow nRow = sheet.createRow(0);
        HSSFCell nCell = nRow.createCell(0);
        //设置列的样式（具体实现在后面......）
        nCell.setCellStyle(this.mainTitleStyle(curStyle, curFont));
        //控制行号列号
        int rowNo = 0;
        int colNo = 0;
        //列标题
        String[] title;
        title = new String[]{"学号", "年龄", "性别", "班级"};
        //设置标题到第一行的列中
        nRow = sheet.createRow(rowNo++);
        for (int i = 0; i < title.length; i++) {
            nCell = nRow.createCell(i);
            nCell.setCellValue(title[i]);
            nCell.setCellStyle(this.textStyle(curStyle, curFont));
        }
        //创建样式和字体(为什么又new，因为下面是正文部分了)
        curStyle = wb.createCellStyle();
        curFont = wb.createFont();
        try {
            //遍历并且创建行列
            colNo = 0;//控制列号
            //每遍历一次创建一行
            nRow = sheet.createRow(rowNo++);
            //学号（先查询出，再将值设置到列中)
            nCell = nRow.createCell(colNo++);
            nCell.setCellValue(0);
            nCell.setCellStyle(this.textStyle(curStyle, curFont));
            //年龄
            nCell = nRow.createCell(colNo++);
            nCell.setCellValue(1);
            nCell.setCellStyle(this.textStyle(curStyle, curFont));
            //性别
            nCell = nRow.createCell(colNo++);
            nCell.setCellValue(2);
            nCell.setCellStyle(this.textStyle(curStyle, curFont));
            //班级
            nCell = nRow.createCell(colNo++);
            nCell.setCellValue(3);
            nCell.setCellStyle(this.textStyle(curStyle, curFont));
            //到这里，excel就已经生成了，然后就需要通过流来写出去
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            //将excel写入流
            wb.write(byteArrayOutputStream);
            //设置文件标题
            String strDateFormat = "yyyyMMddHHmm";
            SimpleDateFormat sdf = new SimpleDateFormat(strDateFormat);
            String dateTime = sdf.format(new Date());
            String outFile = "学生列表-" + dateTime + ".xls";
            //设置返回的文件类型
            response.setContentType("application/vnd.ms-excel;charset=utf-8");
            //对文件编码
            outFile = response.encodeURL(new String(outFile.getBytes("gb2312"), "iso8859-1"));
            //使用Servlet实现文件下载的时候，避免浏览器自动打开文件
            response.addHeader("Content-Disposition", "attachment;filename=" + outFile);
            //设置文件大小
            response.setContentLength(byteArrayOutputStream.size());
            //创建Cookie并添加到response中
            Cookie cookie = new Cookie("fileDownload", "true");
            cookie.setPath("/");
            response.addCookie(cookie);
            //将流写进response输出流中
            ServletOutputStream outputstream = response.getOutputStream();
            byteArrayOutputStream.writeTo(outputstream);
            byteArrayOutputStream.close();
            outputstream.flush();
        } catch (Exception e) {
            return "导出列表失败";
        }
        return "导出成功";

}

    /**
     *  表格标题样式
     * @param curStyle
     * @param curFont
     * @return
     */
    private HSSFCellStyle mainTitleStyle(HSSFCellStyle curStyle, HSSFFont curFont) {
        curFont.setFontName("宋体");    //字体
        curFont.setFontHeightInPoints((short) 16);//字体大小
        curStyle.setFont(curFont); // 绑定关系
        return curStyle;
    }

    /**
     * 表格内容样式
     * @param curStyle
     * @param curFont
     * @return
     */
    private HSSFCellStyle textStyle(HSSFCellStyle curStyle, HSSFFont curFont) {
        curStyle.setWrapText(true); // 自动换行
        curFont.setFontName("Times New Roman");//字体
        curFont.setFontHeightInPoints((short) 10);//字体大小
        curStyle.setFont(curFont); // 绑定关系
        return curStyle;
    }
}
