package com.demo.controller;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.imageio.ImageIO;

import org.apache.poi.hssf.usermodel.HSSFClientAnchor;
import org.apache.poi.hssf.usermodel.HSSFPatriarch;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.ClientAnchor;

public class Picture {
    public static void main(String[] args) {
        //String filepath = SpringConfigUtil.getValue("filepath");
        //String picturepath = SpringConfigUtil.getValue("picturepath");
        //int rowNum = Integer.parseInt(SpringConfigUtil.getValue("rowNum"));
        // int cellNum = Integer.parseInt(SpringConfigUtil.getValue("cellNum"));
        //boolean result = insertPicture("E:\\data\\file\\201509\\2015.xls", "E:\\data\\file\\201509\\test.jpg", 3, 5);// 1代表插入的行数-1
        boolean result = insertPicture("src\\main\\resources\\document\\测试Excel.xls", "src\\main\\resources\\pictures\\link.jpg", 3, 5);// 1代表插入的行数-1
        // ，2代表插入的列数-1

        System.out.println("图片插入结果为==" + result);

    }

    /* 插入图片地址 文件地址 插入图片位置的关键字 图片类型 */

    /**
     * @param filePath
     * @param picturePath
     * @param rowNum
     * @param cellNum
     * @return
     */
    public static boolean insertPicture(String filePath, String picturePath, int rowNum, int cellNum) {
        // 初始化IO流内容

        FileOutputStream fileOut = null;
        BufferedImage bufferImg = null;
        int rowN = rowNum;// 图片插入行的初始化
        int cellN = cellNum;// 图片插入列的初始化
        try {

            // 先把读进来的图片放到一个ByteArrayOutputStream中，以便产生ByteArray
            ByteArrayOutputStream byteArrayOut = new ByteArrayOutputStream();

            bufferImg = ImageIO.read(new File(picturePath));// 图片地址

            ImageIO.write(bufferImg, "png", byteArrayOut);

            // 创建一个工作薄
            HSSFWorkbook wb = new HSSFWorkbook(new FileInputStream(filePath));
            HSSFSheet sheet1 = wb.getSheetAt(0);

            // 创建插入图片需要的容器
            HSSFPatriarch patriarch = sheet1.createDrawingPatriarch();
            /*
             * HSSFClientAnchor几个数字解释：3：是x轴的开始节点， 0：
             * 是y轴的开始节点，1023：是x轴的结束节点，255：是y轴的结束节点
             * ，1：是从Excel的2列开始插入图片，10：是从excel的第11行开始插入图片，
             * 11：图片占用11列的位置，25：图片结束在excel的26行
             */
            HSSFClientAnchor anchor = new HSSFClientAnchor(0, 0, 1023, 255, (short) ((short) cellN), (rowN),
                    (short) ((short) cellN + 1), (rowN));

            //下面这行代码报错。据说是poi版本升级(3.13到4.0.1)导致的。所以要用anchor.setAnchorType(ClientAnchor.AnchorType.DONT_MOVE_AND_RESIZE)
            //anchor.setAnchorType(2);
            anchor.setAnchorType(ClientAnchor.AnchorType.DONT_MOVE_AND_RESIZE);

            // 插入图片

            patriarch.createPicture(anchor, wb.addPicture(byteArrayOut.toByteArray(), HSSFWorkbook.PICTURE_TYPE_JPEG));

            fileOut = new FileOutputStream(filePath);
            // 写入excel文件
            wb.write(fileOut);
            fileOut.close();
            return true;
        } catch (IOException io) {

            io.printStackTrace();

            System.out.println("io erorr :  " + io.getMessage());
            return false;

        } finally {

            if (fileOut != null) {

                try {

                    fileOut.close();

                } catch (IOException e) {

                    e.printStackTrace();

                }
            }
        }

    }
}
