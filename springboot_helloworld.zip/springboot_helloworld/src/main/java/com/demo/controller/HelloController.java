package com.demo.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author Steven
 * @version 1.0
 * @description com.demo.controller
 * @date 2020-4-21
 */
@RestController
@RequestMapping("/test")
public class HelloController {

    //http://localhost:8080/test/hello
    @RequestMapping("/hello")
    public String hello() {
        System.out.println("Hello SpringBoot!");
        return "Hello SpringBoot!";
    }
}
