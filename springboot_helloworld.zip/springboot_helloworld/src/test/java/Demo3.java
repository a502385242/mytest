import java.util.Scanner;

public class Demo3 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int m = sc.nextInt();
        int n = sc.nextInt();
        int count = 0;
        for (int i = 0; i <= n; i++) {
            count = count + sort(m-1,n-i,i);
        }
        System.out.println(count);
    }

    //用递归求解
    public static int sort(int m ,int n,int pre){
        if ( (0 == m && n>0)||(0 == n && m>0)){
            return 0;
        }else if ( m==0 && n==0){
            return 1;
        }
        if (1 == m){
            return 1;
        }
        /*if (2 == m ){
            if (n == 1)
            return 0;
            if (n == 2)
                return 1;
            if (n == 3)
                return 1;
            if (n >= 4)
                return 2;

        }*/
        int countNum = 0;
        for (int i = pre; i <= pre+3; i++) {
            countNum = countNum + sort(m-1,n-i,i);
        }

        return countNum;
    }
}
