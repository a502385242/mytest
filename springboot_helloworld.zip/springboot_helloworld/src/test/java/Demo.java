import java.util.Scanner;

public class Demo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        System.out.println(count(n));
        byte b = 15;
        short c = 15;
    }

    //用递归求解
    public static int count(int n){
        int[]res = new int[n+1];

        if (n<3){
            res = new int[4];
        }
        res[0] = 1;
        //1阶时只有一种方法
        res[1] = 1;
        res[2] = 1;
        res[3] = 2;
        /*res[4] = 3;
        res[5] = 4;
        res[6] = 6;*/
        for (int i = 4; i <= n ; i++) {
            res[i] = res[i-1]+res[i-3];
        }

        return res[n];
    }
}
