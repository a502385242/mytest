import java.util.Queue;

public class TreeNode{
    private String value;
    private TreeNode parentNode;
    private TreeNode leftNode;
    private TreeNode rightNode;

    public TreeNode(){};
    public TreeNode(String value){
        this.value = value;
    };

    public TreeNode(String value, TreeNode parentNode, TreeNode leftNode, TreeNode rightNode) {
        this.value = value;
        this.parentNode = parentNode;
        this.leftNode = leftNode;
        this.rightNode = rightNode;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public TreeNode getParentNode() {
        return parentNode;
    }

    public void setParentNode(TreeNode parentNode) {
        this.parentNode = parentNode;
    }

    public TreeNode getLeftNode() {
        return leftNode;
    }

    public void setLeftNode(TreeNode leftNode) {
        this.leftNode = leftNode;
    }

    public TreeNode getRightNode() {
        return rightNode;
    }

    public void setRightNode(TreeNode rightNode) {
        this.rightNode = rightNode;
    }
}
