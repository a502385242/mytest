import org.springframework.util.CollectionUtils;

import java.util.*;

public class Demo05 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        String[] arr = new String[n];
        for (int i = 0; i < n; i++) {
            arr[i]= String.valueOf(i+1);
        }
        System.out.println(count2(arr));
    }
    public int count(int n){
        //int num = 0;
        int[] arr = new int[n];
        if (0 ==n){
            arr[0] = 0;
        }else if (1==n){
            arr[1] = 1;
        }else if (n>1){
            arr[n] = n+n*count(n-1);
        }
        return arr[n];
    }
    public static List<String> count2(String[] arr){
        List<String> inputStr = CollectionUtils.arrayToList(arr);
        List<String> stringList = new ArrayList<>();
        stringList.addAll(inputStr);
        List<String> outputStrList = new ArrayList<>();
        String str = "";
        addString(stringList,outputStrList,str);
        Queue<TreeNode> queue = new LinkedList<>();
        return outputStrList;
    }

    private static String addString(List<String> stringList,List<String> outputStrList,String str) {

        for (int i = 0; i < stringList.size(); i++) {
            List<String> stringList2 = new ArrayList<>();
            stringList2.addAll(stringList);
            stringList2.remove(i);
            if (stringList.size()!=0){
                str = str + stringList.get(i);
                if (stringList2.size()!=0){
                    str = str + addString(stringList2,outputStrList,str);
                }
                else {
                    outputStrList.add(str);
                    str = "";
                    break;                }

            }
        }
        return str;
    }
}
