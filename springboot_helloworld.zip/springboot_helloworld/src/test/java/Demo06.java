import java.util.*;

public class Demo06 {
    public static void main(String[] args) {
        /*Scanner sc = new Scanner(System.in);
        String str = sc.next();*/
        String str = "cbacdcbc";
        String res = handle(str);
        System.out.println(res);
    }

    private static String handle(String str) {
        String resStr = "";
        StringBuffer sb = new StringBuffer();
        char[] ch = str.toCharArray();
        Set<Character> stringSet = new HashSet<>();
        for (int i = 0; i < ch.length; i++) {
            stringSet.add(ch[i]);
        }
        Character[] chTemp = new Character[stringSet.size()];
        int j = 0;
        for (Character c : stringSet) {
            chTemp[j] = c;
            j++;
        }
        Arrays.sort(chTemp);
        //List<Character> chList = Arrays.asList(chTemp);
        List<Character> chList = new ArrayList<>();
        for (int i = 0; i < chTemp.length; i++) {
            chList.add(chTemp[i]);
        }

        System.out.println(chList);
        //Stack<Character> resStack = new Stack<>();

        //System.out.println(stringSet);
        while (stringSet.size() != 0) {
            List<Character> chTempList = new ArrayList(chList);
            for (Character c : chTempList) {
                boolean flag = false;

                for (int i = 0; i < ch.length; i++) {
                    if (c == ch[i]) {
                        //resStack.push(c);
                        Set<Character> paramSet = new HashSet<>(stringSet);
                        paramSet.remove(c);
                        flag = handle(str.substring(i + 1), paramSet);//可能越界
                        if (flag) {
                            sb.append(c);
                            str = str.substring(i + 1);
                        }
                        break;
                    }
                }
                if (flag) {
                    stringSet.remove(c);
                    chList.remove(c);
                    ch = str.toCharArray();
                    break;
                }
            }
        }
        resStr = sb.toString();
        return resStr;
    }

    private static boolean handle(String str, Set<Character> paramSet) {
        char[] ch = str.toCharArray();
        Set<Character> stringSet = new HashSet<>();
        for (int i = 0; i < ch.length; i++) {
            stringSet.add(ch[i]);
        }
        for (Character c : paramSet){
            if (!stringSet.contains(c)){
                return false;
            }
        }
        return true;
    }
}
