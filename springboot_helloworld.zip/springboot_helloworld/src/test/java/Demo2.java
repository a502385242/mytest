import com.fasterxml.jackson.databind.deser.impl.ManagedReferenceProperty;
import org.apache.xmlbeans.impl.common.ConcurrentReaderHashMap;

import java.util.*;

public class Demo2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String str = sc.next();
        int k = sc.nextInt();
        char[] ch = str.toCharArray();
        HashMap<Character,Integer> countMap = new HashMap<>();
        int i = 0;
        char tempChar = ch[0];
        for (int m = 1; m < ch.length; m++) {
            int countNum = 0;
            //遇到不同字符时计算次数
            if (tempChar != ch[m]){
                countNum = m - i;
                //保存字母出现次数
                if (countMap.containsKey(tempChar)){
                    int tempCount = countMap.get(tempChar);
                    if (countNum > tempCount){
                        countMap.put(tempChar,countNum);
                    }
                }else {
                    countMap.put(tempChar,countNum);
                }
                //开始统计新字母
                i = m;
                tempChar = ch[m];
            }
            //字符串到达末尾时需要特殊处理
            if (tempChar == ch[m] && m ==(ch.length-1)){
                countNum = m - i + 1;
                //保存字母出现次数
                if (countMap.containsKey(tempChar)){
                    int tempCount = countMap.get(tempChar);
                    if (countNum > tempCount){
                        countMap.put(tempChar,countNum);
                    }
                }else {
                    countMap.put(tempChar,countNum);
                }
            }
        }
        List<HashMap.Entry<Character,Integer>> list = new ArrayList<>();
        list.addAll(countMap.entrySet());
        Collections.sort(list, new Comparator<HashMap.Entry<Character, Integer>>() {
            @Override
            public int compare(Map.Entry<Character, Integer> o1, Map.Entry<Character, Integer> o2) {
                return o2.getValue()-o1.getValue();
            }
        });
        if (k>list.size()){
            k =list.size();
        }
        System.out.println(list.get(k-1).getValue());
    }
}
