import java.util.ArrayList;
import java.util.List;

public class Demo07 {
    public static void main(String[] args) {
        String str = "az-AZ";
        String resStr = splitAndReverse(str);
        String word = str.substring(0,2);
        System.out.println(str);
        System.out.println(word);
    }

    private static String splitAndReverse(String str) {
        String resStr = "";
        List<String> strList = new ArrayList<>();
        int indexNow = 0;
        for (int i = 0; i < str.length(); i++) {
            char c = str.charAt(i);
            String word = "";
            if (!checkWord(c)) {
                if ('-' == c){
                    //处理
                }else {
                    word = str.substring(indexNow,i);
                    if (0!=word.length()){
                        strList.add(word);
                        indexNow = i+1;
                    }
                }
            }
            //System.out.println(flag);
        }
        return resStr;
    }

    private static boolean checkWord(char c) {
        if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')) {
            return true;
        }
        return false;
    }


}
