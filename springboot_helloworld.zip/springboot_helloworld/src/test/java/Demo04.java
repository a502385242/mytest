import com.sun.org.apache.xpath.internal.operations.String;

import javax.xml.soap.Node;
import java.util.ArrayList;
import java.util.List;

public class Demo04 {
    public static void main(String[] args) {
        java.lang.String []strArr = {"1","2","3",null,"4","5"};
        List<TreeNode> treeNodeList = new ArrayList<>();
        TreeNode headNode = null;
        for (int i = 0; i < strArr.length; i++) {
            TreeNode nowNode = null;
            if (headNode ==null){
                headNode = new TreeNode(strArr[i],null,null,null);
                nowNode = headNode;
            }else {
                nowNode = addNode( headNode, strArr[i], nowNode);
            }
            treeNodeList.add(nowNode);

        }

    }

    private static TreeNode addNode(TreeNode headNode, java.lang.String value, TreeNode nowNode) {
        TreeNode node = null;
        //父节点为空说明是头结点
        if (nowNode.getParentNode()==null){
            if (nowNode.getLeftNode()==null){
               node = new TreeNode(value,nowNode,null,null);
                nowNode.setLeftNode(node);
                nowNode = node;
                return nowNode;


            }else if (nowNode.getRightNode()==null){
                node = new TreeNode(value,nowNode,null,null);
                nowNode.setRightNode(nowNode);
                nowNode = node;
                return nowNode;
            }else {
                nowNode.getLeftNode();
            }
        }
        else {
            addNode(headNode,value,nowNode.getParentNode());
        }
        return null;
    }


}

